# CIS262 AD - Fall 2023
## Chapter 20
## Antony Gradillas

1. c) Generic classes
2. a) compile-time type safety
3. e) All of the above
4. True
5. True
6. b) angle brackets
7. a) is an identifier that is used in place of an actual type name
8. False
9. False
10. b) generic class

