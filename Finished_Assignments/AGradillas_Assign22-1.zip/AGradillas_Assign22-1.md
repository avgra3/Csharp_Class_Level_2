# Antony Gradillas
# Assign22-1 Assignment Questions

1. SQL is an acronym for:
    c) Structured Query Language

2. Today's most popular database systems are ___.
    d) Relational databases.

3. True/False) A query is a request to the database for the data that satisfies the specified criteria.
    True.

4. True/False) Database management systems enable you to access and store data without worrying about the external representation databases.
    False.

5. Relational databases can be thought of as ___.
    c) Tables of rows and columns.

6. A relational database model allows relationships between data to be considered without concern for the ___.
    a) meaning of the data

7. (True/False) An ADO.NET Entity Data Model contains only classes that represent the database's tables.
    True

8. (True/False) A relational database model is a way of organizing data and considering relationships based on the physical structure of the data.
    False

9. (True/False) A primary key must be unique for each record in the relational database table.
    True.

10. (True/False) A primary key field can be duplicated in other records of the same relational database table, making it easier to manipulate.
    False

11. (True/False) It's possible to select only a subset of a relational database table's columns.
    True.

12. There is a __ relationship between a primary key and its corresponding foreign key.
    C) one-to-many

13. (True/False) Each foreign key can be created independently.
    True

14. An object of a subclass of __ is used to manage the data flow beteen your program and the database.
    c) DbContext

15. (True/False) An ADO.NET Entity Data Model contains only classes that represent te database's tables.
    True.

16. (True/False) An ADO.NET Entity Data Model cannot represent the relationships between tables in a database.
    False.

17. Tables from databases are commonly shown in a GUI through ___.
    b. DataGridView

18. The `BindingNavigator` allows the user ___.
    d) All of the above.

19. (True/False) When various databases are combined, this known as data binding.
        False

20. (True/False) `DBExtensions` method `Load` loads an entire database's data into a `DbContext`.
    False

21. You can call a `BindingSource`'s ___ method to move to the first row of the result.
    b) MoveFirst

22. The extension method __ is used to filter the results of a LINQ query.
    c) Where

23. (True/False) A LINQ query may contain only one from `from` clause.
    False

24. (True/False) It's possible to nest LINQ queries to produce hierarchical results.
    True

25. (True/False) A master/detail view app typically allows the user to select an entry to see (and potentially manipulate) the details associated with the entry.
    True
